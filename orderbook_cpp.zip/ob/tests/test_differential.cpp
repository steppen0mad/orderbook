//
// test_differential.cpp -- fuzz the fast book against the naive reference.
//
// Generates a long random stream of operations (adds of every order type,
// cancels, modifies) and applies each to BOTH books. After every operation it
// asserts the two produced identical trades, and periodically asserts the full
// resting state (top of book + per-level quantities) matches. Any divergence
// is a bug in the fast book, since the reference is trivially correct.
//
#include "ob/order_book.hpp"
#include "ob/reference_book.hpp"
#include <random>
#include <vector>
#include <iostream>
#include <cstdint>

using namespace ob;

namespace {

constexpr Price       MINP = 1;
constexpr Price       MAXP = 2000;          // 2000-tick band
constexpr std::size_t CAP  = 1 << 20;
#ifndef OPS
#define OPS 3000000
#endif

bool sameTrades(const std::vector<Trade>& a, const std::vector<Trade>& b) {
    if (a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) {
        if (a[i].aggressor != b[i].aggressor || a[i].resting != b[i].resting ||
            a[i].price != b[i].price || a[i].quantity != b[i].quantity)
            return false;
    }
    return true;
}

} // namespace

int main() {
    std::mt19937_64 rng(0xC0FFEEu);
    auto pick   = [&](int lo, int hi) { return std::uniform_int_distribution<int>(lo, hi)(rng); };

    OrderBook     fast(MINP, MAXP, CAP);
    ReferenceBook ref (MINP, MAXP, CAP);

    std::vector<OrderId> live;                 // ids believed resting (best-effort)
    OrderId next_id = 1;
    long total_trades = 0;

    for (int op = 0; op < OPS; ++op) {
        const int roll = pick(0, 99);
        std::vector<Trade> tf, tr;

        if (roll < 60) {                       // 60% submit
            Side side = pick(0, 1) ? Side::Buy : Side::Sell;
            int  tsel = pick(0, 9);
            OrderType type = tsel < 6 ? OrderType::Limit
                           : tsel < 8 ? OrderType::IOC
                           : tsel < 9 ? OrderType::FOK
                                      : OrderType::Market;
            Price px = pick(MINP, MAXP);
            Quantity qty = pick(1, 50);
            OrderId id = next_id++;
            fast.submit(id, side, type, px, qty, tf);
            ref .submit(id, side, type, px, qty, tr);
            if (type == OrderType::Limit) live.push_back(id);
        } else if (roll < 80 && !live.empty()) {   // 20% cancel
            std::size_t k = static_cast<std::size_t>(pick(0, (int)live.size() - 1));
            OrderId id = live[k];
            bool a = fast.cancel(id);
            bool b = ref .cancel(id);
            if (a != b) { std::cerr << "cancel mismatch id=" << id << " op=" << op << "\n"; return 1; }
            live[k] = live.back(); live.pop_back();
        } else if (!live.empty()) {                 // ~20% modify
            std::size_t k = static_cast<std::size_t>(pick(0, (int)live.size() - 1));
            OrderId id = live[k];
            Price npx = pick(MINP, MAXP);
            Quantity nq = pick(1, 60);
            fast.modify(id, npx, nq, tf);
            ref .modify(id, npx, nq, tr);
            // a repriced/increased modify may execute or re-rest; stop tracking precisely
            live[k] = live.back(); live.pop_back();
        }

        if (!sameTrades(tf, tr)) {
            std::cerr << "TRADE MISMATCH at op " << op
                      << " (fast " << tf.size() << " vs ref " << tr.size() << ")\n";
            return 1;
        }
        total_trades += (long)tf.size();

        if ((op & 0x3FFF) == 0) {              // periodic full-state check
            if (fast.bestBid() != ref.bestBid() || fast.bestAsk() != ref.bestAsk()) {
                std::cerr << "TOP-OF-BOOK MISMATCH at op " << op
                          << " fast(" << fast.bestBid() << "/" << fast.bestAsk() << ") "
                          << "ref(" << ref.bestBid() << "/" << ref.bestAsk() << ")\n";
                return 1;
            }
            for (Price p = MINP; p <= MAXP; ++p) {
                if (fast.qtyAtPrice(p) != ref.qtyAtPrice(p)) {
                    std::cerr << "LEVEL QTY MISMATCH at op " << op << " price " << p
                              << " fast " << fast.qtyAtPrice(p) << " ref " << ref.qtyAtPrice(p) << "\n";
                    return 1;
                }
            }
        }
    }

    std::cout << "differential fuzz passed: " << OPS << " ops, "
              << total_trades << " trades, fast and reference agreed throughout\n";
    return 0;
}

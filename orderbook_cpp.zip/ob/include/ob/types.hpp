#pragma once
//
// types.hpp -- fundamental value types for the order book.
//
// Design note: prices are INTEGER TICKS, never floating point.
//   A `double` cannot represent most decimal prices exactly, so using it as a
//   std::map key (as the first version did) means equality comparisons are
//   unreliable and matching can silently miss. Exchanges quote in discrete
//   ticks (e.g. cents, or 1/100 of a cent), so an integer tick is both exact
//   and faster to compare. The mapping ticks <-> real price lives at the I/O
//   boundary only; the engine never sees a float.
//
#include <cstdint>
#include <limits>

namespace ob {

using OrderId   = std::uint64_t;   // exchange-assigned identifier
using Price     = std::int64_t;    // price in integer ticks
using Quantity  = std::int64_t;    // share/lot count (signed to catch underflow in asserts)
using Slot      = std::uint32_t;   // index into the order pool (stable handle)

inline constexpr Slot  NULL_SLOT = std::numeric_limits<Slot>::max();
inline constexpr Price NO_PRICE  = std::numeric_limits<Price>::min();

enum class Side : std::uint8_t { Buy, Sell };

// Order types model the common exchange semantics:
//   Limit  - match what crosses, rest the remainder in the book.
//   Market - match against the book at any price, never rest; cancel remainder.
//   IOC    - Immediate-Or-Cancel: match immediately, cancel the remainder (never rests).
//   FOK    - Fill-Or-Kill: only execute if the ENTIRE quantity can fill now, else reject whole.
enum class OrderType : std::uint8_t { Limit, Market, IOC, FOK };

inline constexpr Side opposite(Side s) noexcept {
    return s == Side::Buy ? Side::Sell : Side::Buy;
}

// Emitted on every (partial or full) execution. Kept trivially copyable and
// small so it can be pushed into a flat vector with no allocation surprises.
struct Trade {
    OrderId  aggressor;   // the incoming order that crossed
    OrderId  resting;     // the passive order it matched against
    Price    price;       // execution price = the RESTING order's price (price-time priority)
    Quantity quantity;    // matched size
};

} // namespace ob

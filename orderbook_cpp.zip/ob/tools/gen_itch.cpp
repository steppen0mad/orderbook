//
// gen_itch.cpp -- write a synthetic, self-consistent NASDAQ ITCH 5.0 file.
//
// Real NASDAQ sample files are multi-gigabyte and not redistributable here, so
// this produces a valid length-prefixed ITCH 5.0 stream for a single symbol so
// the replay tool can run end-to-end. The byte layout matches the real spec
// (big-endian, same field offsets), so the same parser reads genuine NASDAQ
// files -- see README for how to point replay_itch at one.
//
// Bids are placed strictly below a mid and asks strictly above it, so the
// reconstructed book never crosses -- mirroring a real feed, where the exchange
// has already matched anything marketable before publishing.
//
#include "ob/itch.hpp"
#include <cstdio>
#include <cstdint>
#include <random>
#include <vector>

using namespace ob;

namespace {
std::vector<std::uint8_t> out;

void put16(std::uint16_t v) { out.push_back(v >> 8); out.push_back(v & 0xff); }
void put32(std::uint32_t v) { for (int i = 3; i >= 0; --i) out.push_back((v >> (i*8)) & 0xff); }
void put48(std::uint64_t v) { for (int i = 5; i >= 0; --i) out.push_back((v >> (i*8)) & 0xff); }
void put64(std::uint64_t v) { for (int i = 7; i >= 0; --i) out.push_back((v >> (i*8)) & 0xff); }

void begin(std::uint16_t body_len) { put16(body_len); }
void header(char type, std::uint64_t ts) {
    out.push_back((std::uint8_t)type);
    put16(1);          // stock locate
    put16(0);          // tracking number
    put48(ts);         // timestamp (ns since midnight)
}

struct LiveOrder { std::uint64_t ref; char side; };
} // namespace

int main(int argc, char** argv) {
    const char* path = (argc > 1) ? argv[1] : "feed.itch";
    const int   N    = (argc > 2) ? std::atoi(argv[2]) : 5'000'000;

    // Symbol near $100.00 == 1,000,000 in 1/10000 units. Bids in [MID-H, MID-1],
    // asks in [MID+1, MID+H], so bid < ask always.
    const std::uint32_t MID = 1'000'000, H = 25'000;
    std::mt19937_64 rng(2024);
    auto U = [&](int lo, int hi){ return std::uniform_int_distribution<int>(lo, hi)(rng); };
    auto priceFor = [&](char side){
        return side == 'B' ? MID - (std::uint32_t)U(1, H)   // strictly below mid
                           : MID + (std::uint32_t)U(1, H);  // strictly above mid
    };

    std::vector<LiveOrder> live;
    std::uint64_t next_ref = 1, ts = 34'200'000'000'000ull, match_no = 1;

    { begin(12); header('S', ts); out.push_back('O'); }    // system event (unhandled type)

    auto pickLive = [&](std::size_t& k)->bool {
        if (live.empty()) return false;
        k = (std::size_t)U(0, (int)live.size()-1);
        return true;
    };
    auto removeLive = [&](std::size_t k){ live[k] = live.back(); live.pop_back(); };

    for (int i = 0; i < N; ++i) {
        int r = U(0, 99);
        std::size_t k;
        if (r < 50 || live.size() < 16) {            // Add
            std::uint64_t ref = next_ref++;
            char side = U(0,1) ? 'B' : 'S';
            begin(36); header('A', ts += U(1,500));
            put64(ref); out.push_back((std::uint8_t)side);
            put32((std::uint32_t)U(1,1000));
            const char* sym = "TESTSYM "; out.insert(out.end(), sym, sym + 8);
            put32(priceFor(side));
            live.push_back({ref, side});
        } else if (r < 70) {                          // Execute (trade against resting)
            if (!pickLive(k)) continue;
            begin(31); header('E', ts += U(1,500));
            put64(live[k].ref); put32((std::uint32_t)U(1,100)); put64(match_no++);
        } else if (r < 82) {                          // Cancel (partial reduce)
            if (!pickLive(k)) continue;
            begin(23); header('X', ts += U(1,500));
            put64(live[k].ref); put32((std::uint32_t)U(1,50));
        } else if (r < 94) {                          // Delete (full)
            if (!pickLive(k)) continue;
            begin(19); header('D', ts += U(1,500));
            put64(live[k].ref); removeLive(k);
        } else {                                      // Replace (same side, new ref/price)
            if (!pickLive(k)) continue;
            std::uint64_t nref = next_ref++;
            char side = live[k].side;
            begin(35); header('U', ts += U(1,500));
            put64(live[k].ref); put64(nref);
            put32((std::uint32_t)U(1,1000)); put32(priceFor(side));
            live[k] = {nref, side};
        }
    }

    FILE* f = std::fopen(path, "wb");
    if (!f) { std::perror("fopen"); return 1; }
    std::fwrite(out.data(), 1, out.size(), f);
    std::fclose(f);
    std::printf("wrote %s: %zu bytes, ~%d messages\n", path, out.size(), N);
    return 0;
}

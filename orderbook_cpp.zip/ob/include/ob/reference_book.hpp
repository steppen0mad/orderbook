#pragma once
//
// reference_book.hpp -- a deliberately naive, obviously-correct order book.
//
// This is NOT the fast path. It exists only to validate the fast book: run the
// same operation stream through both and assert identical trades and identical
// resting state. A slow reference you trust + differential fuzzing is a much
// stronger correctness argument than hand-written unit tests alone, because it
// explores order interleavings you would never think to write by hand.
//
#include "types.hpp"
#include <map>
#include <list>
#include <unordered_map>
#include <vector>

namespace ob {

class ReferenceBook {
public:
    ReferenceBook(Price /*min*/, Price /*max*/, std::size_t /*cap*/) {}

    Quantity submit(OrderId id, Side side, OrderType type, Price price,
                    Quantity qty, std::vector<Trade>& trades) {
        const Price limit = (type == OrderType::Market)
                                ? (side == Side::Buy ? kMax : kMin)
                                : price;
        if (type == OrderType::FOK && available(side, limit) < qty) return 0;

        const Quantity incoming = qty;
        if (side == Side::Buy) {
            while (qty > 0 && !asks_.empty()) {
                auto lvl = asks_.begin();
                if (lvl->first > limit) break;
                qty = take(lvl->second, lvl->first, qty, id, trades);
                if (lvl->second.empty()) asks_.erase(lvl);
            }
        } else {
            while (qty > 0 && !bids_.empty()) {
                auto lvl = bids_.begin();
                if (lvl->first < limit) break;
                qty = take(lvl->second, lvl->first, qty, id, trades);
                if (lvl->second.empty()) bids_.erase(lvl);
            }
        }
        if (qty > 0 && type == OrderType::Limit) {
            auto& q = (side == Side::Buy) ? bids_[price] : asks_[price];
            q.push_back({id, qty});
            loc_[id] = {side, price};
        }
        return incoming - qty;
    }

    bool cancel(OrderId id) {
        auto it = loc_.find(id);
        if (it == loc_.end()) return false;
        eraseFrom(it->second.first, it->second.second, id);
        loc_.erase(it);
        return true;
    }

    bool modify(OrderId id, Price new_price, Quantity new_qty, std::vector<Trade>& trades) {
        auto it = loc_.find(id);
        if (it == loc_.end()) return false;
        if (new_qty <= 0) return cancel(id);
        Side side = it->second.first; Price px = it->second.second;
        auto& q = (side == Side::Buy) ? bids_[px] : asks_[px];
        for (auto& e : q) {
            if (e.first == id) {
                if (new_price == px && new_qty <= e.second) { e.second = new_qty; return true; }
                break;
            }
        }
        cancel(id);
        submit(id, side, OrderType::Limit, new_price, new_qty, trades);
        return true;
    }

    Price bestBid() const { return bids_.empty() ? NO_PRICE : bids_.begin()->first; }
    Price bestAsk() const { return asks_.empty() ? NO_PRICE : asks_.begin()->first; }
    Quantity qtyAtPrice(Price p) const {
        Quantity t = 0;
        if (auto i = bids_.find(p); i != bids_.end()) for (auto& e : i->second) t += e.second;
        if (auto i = asks_.find(p); i != asks_.end()) for (auto& e : i->second) t += e.second;
        return t;
    }

private:
    static constexpr Price kMax = 1'000'000'000;
    static constexpr Price kMin = -1'000'000'000;
    using Queue = std::list<std::pair<OrderId, Quantity>>;  // (id, qty) in FIFO order

    Quantity take(Queue& q, Price px, Quantity qty, OrderId aggr, std::vector<Trade>& trades) {
        while (qty > 0 && !q.empty()) {
            auto& front = q.front();
            Quantity traded = qty < front.second ? qty : front.second;
            trades.push_back(Trade{aggr, front.first, px, traded});
            qty -= traded; front.second -= traded;
            if (front.second == 0) { loc_.erase(front.first); q.pop_front(); }
        }
        return qty;
    }
    template <class Map>
    static void eraseIn(Map& m, Price px, OrderId id) {
        auto lvl = m.find(px);
        if (lvl == m.end()) return;
        for (auto i = lvl->second.begin(); i != lvl->second.end(); ++i)
            if (i->first == id) { lvl->second.erase(i); break; }
        if (lvl->second.empty()) m.erase(lvl);
    }
    void eraseFrom(Side side, Price px, OrderId id) {
        if (side == Side::Buy) eraseIn(bids_, px, id);
        else                   eraseIn(asks_, px, id);
    }
    Quantity available(Side side, Price limit) const {
        Quantity a = 0;
        if (side == Side::Buy) { for (auto& [px, q] : asks_) { if (px > limit) break; for (auto& e : q) a += e.second; } }
        else                   { for (auto& [px, q] : bids_) { if (px < limit) break; for (auto& e : q) a += e.second; } }
        return a;
    }

    std::map<Price, Queue, std::greater<Price>> bids_;
    std::map<Price, Queue, std::less<Price>>    asks_;
    std::unordered_map<OrderId, std::pair<Side, Price>> loc_;
};

} // namespace ob

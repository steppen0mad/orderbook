//
// test_matching.cpp -- targeted unit tests for the tricky semantics.
//
#include "ob/order_book.hpp"
#include <vector>
#include <iostream>
#include <cstdlib>

using namespace ob;

static int g_failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { std::cerr << "FAIL " << __LINE__ << ": " #cond "\n"; ++g_failures; } \
} while (0)

static OrderBook makeBook() { return OrderBook(/*min*/1, /*max*/100000, /*cap*/1<<20); }

static void test_rest_and_top() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Buy,  OrderType::Limit, 100, 10, t);
    b.submit(2, Side::Sell, OrderType::Limit, 105,  5, t);
    CHECK(t.empty());                 // no cross
    CHECK(b.bestBid() == 100);
    CHECK(b.bestAsk() == 105);
    CHECK(b.qtyAtPrice(100) == 10);
}

static void test_partial_fill_rests_remainder() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);
    b.submit(2, Side::Buy,  OrderType::Limit, 100, 8, t);   // lifts 5, rests 3
    CHECK(t.size() == 1);
    CHECK(t[0].price == 100 && t[0].quantity == 5);
    CHECK(b.bestAsk() == NO_PRICE);   // ask fully consumed
    CHECK(b.bestBid() == 100);
    CHECK(b.qtyAtPrice(100) == 3);
}

static void test_fifo_time_priority() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);  // older
    b.submit(2, Side::Sell, OrderType::Limit, 100, 5, t);  // newer
    b.submit(3, Side::Buy,  OrderType::Limit, 100, 6, t);  // should hit id 1 first
    CHECK(t.size() == 2);
    CHECK(t[0].resting == 1 && t[0].quantity == 5);        // oldest first
    CHECK(t[1].resting == 2 && t[1].quantity == 1);
    CHECK(b.qtyAtPrice(100) == 4);                          // 4 left on id 2
}

static void test_multi_level_sweep() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);
    b.submit(2, Side::Sell, OrderType::Limit, 101, 5, t);
    b.submit(3, Side::Sell, OrderType::Limit, 102, 5, t);
    b.submit(4, Side::Buy,  OrderType::Limit, 101, 8, t);   // sweeps 100 then 101
    CHECK(t.size() == 2);
    CHECK(t[0].price == 100 && t[0].quantity == 5);
    CHECK(t[1].price == 101 && t[1].quantity == 3);
    CHECK(b.bestAsk() == 101);          // 2 left at 101
    CHECK(b.qtyAtPrice(101) == 2);
    CHECK(b.bestBid() == NO_PRICE);     // buy fully filled, nothing rests
}

static void test_cancel() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Buy, OrderType::Limit, 100, 10, t);
    b.submit(2, Side::Buy, OrderType::Limit, 100, 20, t);
    CHECK(b.cancel(1));
    CHECK(!b.cancel(1));               // already gone
    CHECK(b.qtyAtPrice(100) == 20);
    CHECK(b.cancel(2));
    CHECK(b.bestBid() == NO_PRICE);    // level emptied, cursor re-seated
}

static void test_modify_down_keeps_priority() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 10, t); // older
    b.submit(2, Side::Sell, OrderType::Limit, 100, 10, t); // newer
    b.modify(1, 100, 4, t);            // reduce qty, keep priority
    b.submit(3, Side::Buy, OrderType::Limit, 100, 4, t);   // should still hit id 1 first
    CHECK(t.size() == 1);
    CHECK(t[0].resting == 1);          // priority retained
    CHECK(b.qtyAtPrice(100) == 10);    // id 2 untouched
}

static void test_modify_up_loses_priority() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);  // older
    b.submit(2, Side::Sell, OrderType::Limit, 100, 5, t);  // newer
    b.modify(1, 100, 12, t);           // increase qty -> goes to back of queue
    b.submit(3, Side::Buy, OrderType::Limit, 100, 5, t);   // should now hit id 2 first
    CHECK(t.size() == 1);
    CHECK(t[0].resting == 2);          // id 1 lost priority
}

static void test_modify_price_can_cross() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 105, 5, t);
    b.submit(2, Side::Buy,  OrderType::Limit, 100, 5, t);
    CHECK(t.empty());
    b.modify(2, 105, 5, t);            // reprice the buy up to 105 -> crosses
    CHECK(t.size() == 1);
    CHECK(t[0].price == 105 && t[0].quantity == 5);
    CHECK(b.bestAsk() == NO_PRICE && b.bestBid() == NO_PRICE);
}

static void test_ioc_does_not_rest() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);
    Quantity filled = b.submit(2, Side::Buy, OrderType::IOC, 100, 8, t);
    CHECK(filled == 5);
    CHECK(b.bestBid() == NO_PRICE);    // remainder cancelled, nothing rests
    CHECK(b.bestAsk() == NO_PRICE);
}

static void test_fok_all_or_nothing() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);
    Quantity filled = b.submit(2, Side::Buy, OrderType::FOK, 100, 8, t); // can't fully fill
    CHECK(filled == 0);
    CHECK(t.empty());                  // nothing executed
    CHECK(b.qtyAtPrice(100) == 5);     // resting ask untouched
    Quantity filled2 = b.submit(3, Side::Buy, OrderType::FOK, 100, 5, t); // exact fill
    CHECK(filled2 == 5);
    CHECK(b.bestAsk() == NO_PRICE);
}

static void test_market_order() {
    auto b = makeBook(); std::vector<Trade> t;
    b.submit(1, Side::Sell, OrderType::Limit, 100, 5, t);
    b.submit(2, Side::Sell, OrderType::Limit, 110, 5, t);
    Quantity filled = b.submit(3, Side::Buy, OrderType::Market, 0, 7, t); // ignores price
    CHECK(filled == 7);
    CHECK(t.size() == 2);
    CHECK(t[0].price == 100 && t[1].price == 110);
    CHECK(b.qtyAtPrice(110) == 3);
}

int main() {
    test_rest_and_top();
    test_partial_fill_rests_remainder();
    test_fifo_time_priority();
    test_multi_level_sweep();
    test_cancel();
    test_modify_down_keeps_priority();
    test_modify_up_loses_priority();
    test_modify_price_can_cross();
    test_ioc_does_not_rest();
    test_fok_all_or_nothing();
    test_market_order();

    if (g_failures == 0) { std::cout << "all unit tests passed\n"; return 0; }
    std::cerr << g_failures << " failure(s)\n";
    return 1;
}

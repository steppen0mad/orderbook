#pragma once
//
// order_pool.hpp -- a fixed-capacity arena of order nodes.
//
// Why this exists: the first version stored std::deque<Order>::iterator inside
// the order index. A deque invalidates all iterators when it grows, so cancels
// after enough adds dereferenced dangling iterators (AddressSanitizer flagged a
// heap-use-after-free). An arena fixes this structurally:
//
//   * Every order lives in a slot in one contiguous vector, reserved up front.
//   * Handles are Slot indices, which never move or dangle.
//   * Free slots form an intrusive singly-linked free list (reusing `next`),
//     so allocate/free are O(1) and perform ZERO heap allocation in steady
//     state -- the property that matters for tail latency.
//
#include "types.hpp"
#include <vector>
#include <cassert>

namespace ob {

// One resting order. The prev/next fields make each price level an intrusive
// doubly-linked FIFO queue, so removal from the middle (a cancel) is O(1)
// without searching.
struct OrderNode {
    OrderId  id;
    Price    price;      // in ticks
    Quantity qty;        // remaining quantity
    Side     side;
    Slot     prev;       // previous order at the same price level (NULL_SLOT if head)
    Slot     next;       // next order at the same level, OR next free slot when on free list
};

class OrderPool {
public:
    explicit OrderPool(std::size_t capacity) {
        nodes_.resize(capacity);
        // Thread every slot onto the free list: 0 -> 1 -> ... -> n-1 -> NULL.
        for (Slot i = 0; i + 1 < capacity; ++i) nodes_[i].next = i + 1;
        if (capacity) nodes_[capacity - 1].next = NULL_SLOT;
        free_head_ = capacity ? 0 : NULL_SLOT;
    }

    // O(1). Returns NULL_SLOT if the arena is exhausted (capacity is a hard cap).
    Slot allocate() noexcept {
        if (free_head_ == NULL_SLOT) return NULL_SLOT;
        Slot s = free_head_;
        free_head_ = nodes_[s].next;
        ++live_;
        return s;
    }

    // O(1). Returns the slot to the free list for reuse.
    void deallocate(Slot s) noexcept {
        assert(s < nodes_.size());
        nodes_[s].next = free_head_;
        free_head_ = s;
        --live_;
    }

    OrderNode&       operator[](Slot s) noexcept       { return nodes_[s]; }
    const OrderNode& operator[](Slot s) const noexcept { return nodes_[s]; }

    std::size_t live() const noexcept { return live_; }

private:
    std::vector<OrderNode> nodes_;
    Slot        free_head_ = NULL_SLOT;
    std::size_t live_      = 0;
};

} // namespace ob

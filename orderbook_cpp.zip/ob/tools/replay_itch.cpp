//
// replay_itch.cpp -- reconstruct an order book from an ITCH 5.0 feed.
//
// Reads a length-prefixed ITCH 5.0 file into memory, then drives the order book
// from the message stream and reports decode+reconstruct throughput plus the
// final top of book. The same code reads real NASDAQ TotalView-ITCH 5.0 files
// for a single symbol (filter the stream / widen the band accordingly).
//
#include "ob/order_book.hpp"
#include "ob/itch.hpp"
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <fstream>
#include <vector>

using namespace ob;

// Sink that turns ITCH events into book operations. The book itself tracks
// ref -> location, so reconstruction needs no side bookkeeping of its own.
struct Reconstructor {
    OrderBook& book;
    long adds = 0, execs = 0, cancels = 0, deletes = 0, replaces = 0;
    long traded_shares = 0;
    std::vector<Trade> scratch;

    explicit Reconstructor(OrderBook& b) : book(b) { scratch.reserve(64); }
    void onAdd(const itch::AddOrder& a) {
        book.addResting(a.ref, a.side, (Price)a.price, (Quantity)a.shares);
        ++adds;
    }
    void onExec(const itch::OrderExecuted& e)   { reduce(e.ref, e.shares); traded_shares += e.shares; ++execs; }
    void onExecPx(const itch::OrderExecutedPx& e){ reduce(e.ref, e.shares); traded_shares += e.shares; ++execs; }
    void onCancel(const itch::OrderCancel& c)   { reduce(c.ref, c.shares); ++cancels; }
    void onDelete(const itch::OrderDelete& d)   { book.cancel(d.ref); ++deletes; }
    void onReplace(const itch::OrderReplace& u) {
        Side s; Price p; Quantity q;
        if (book.getOrder(u.old_ref, s, p, q)) {
            book.cancel(u.old_ref);
            book.addResting(u.new_ref, s, (Price)u.price, (Quantity)u.shares);
        }
        ++replaces;
    }

private:
    void reduce(std::uint64_t ref, std::uint32_t shares) {
        Side s; Price p; Quantity q;
        if (!book.getOrder(ref, s, p, q)) return;
        scratch.clear();
        book.modify(ref, p, q - (Quantity)shares, scratch);  // <=0 cancels; else keeps priority
    }
};

int main(int argc, char** argv) {
    const char* path = (argc > 1) ? argv[1] : "feed.itch";
    std::ifstream f(path, std::ios::binary);
    if (!f) { std::fprintf(stderr, "cannot open %s\n", path); return 1; }
    std::vector<std::uint8_t> buf((std::istreambuf_iterator<char>(f)),
                                   std::istreambuf_iterator<char>());
    std::printf("loaded %s: %.2f MB\n", path, buf.size() / 1e6);

    // Band must cover the symbol's price range; synthetic feed lives near $100.
    OrderBook book(/*min*/900'000, /*max*/1'100'000, /*cap*/8'000'000);
    Reconstructor rec{book};

    auto t0 = std::chrono::steady_clock::now();
    std::size_t msgs = itch::parse(buf.data(), buf.size(), rec);
    auto t1 = std::chrono::steady_clock::now();
    double secs = std::chrono::duration<double>(t1 - t0).count();

    std::printf("decoded+reconstructed %zu messages in %.3f s\n", msgs, secs);
    std::printf("  %.2f M msg/s, %.0f MB/s\n", msgs / secs / 1e6, buf.size() / secs / 1e6);
    std::printf("  adds=%ld exec=%ld cancel=%ld delete=%ld replace=%ld traded_shares=%ld\n",
                rec.adds, rec.execs, rec.cancels, rec.deletes, rec.replaces, rec.traded_shares);

    auto px = [](Price p){ return p == NO_PRICE ? -1.0 : p / 10000.0; };
    std::printf("  final book: bestBid=%.4f bestAsk=%.4f resting=%zu\n",
                px(book.bestBid()), px(book.bestAsk()), book.restingCount());
    return 0;
}
